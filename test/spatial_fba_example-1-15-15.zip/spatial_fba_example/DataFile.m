function DF = DataFile(TSTART,TSTOP,Ts,INDEX)

% Load the stoichiometric matrix and flux bounds array - 
stoichiometric_matrix = load('Network.dat');
flux_bounds_array = load('FB.dat');
[number_of_species,number_of_reactions] = size(stoichiometric_matrix);

% Setup the free metabolite array - 
IDX_FREE_METABOLITES = [
	28	1	;	% 1 Ax
	29	2	;	% 2 Bx
	30	3	;	% 3 Cx
];

% Split the stoichiometric matrix - 
IDX_BALANCED_METABOLITES = setdiff(1:number_of_species,IDX_FREE_METABOLITES(:,1));
N_IDX_BALANCED_METABOLITES = length(IDX_BALANCED_METABOLITES);

% Setup the bounds on species - 
BASE_BOUND = 1;
SPECIES_BOUND = [
	28	0	BASE_BOUND	;	% 1 Ax
	29	0	BASE_BOUND	;	% 2 Bx
	30	0	BASE_BOUND	;	% 3 Cx
];

% Crowding hack -
CROWDING_COEFF_VECTOR = [
	0.1	;	% subcompartment 1
	1.0	;	% subcompartment 2
	0.1	;	% subcompartment 3
	1.0	;	% subcompartment 4
	1.0	;	% subcompartment 5
	1.0	;	% subcompartment 6
	0.0	;	% subcompartment 7
	1.0	;	% subcompartment 8
	0.1	;	% subcompartment 9
];

CONSTRAINT_CROWDING = zeros(9,number_of_reactions);
CONSTRAINT_CROWDING(1,1:4) = 1;
CONSTRAINT_CROWDING(2,5:8) = 1;
CONSTRAINT_CROWDING(3,9:12) = 1;
CONSTRAINT_CROWDING(4,13:16) = 1;
CONSTRAINT_CROWDING(5,17:20) = 1;
CONSTRAINT_CROWDING(6,21:24) = 1;
CONSTRAINT_CROWDING(7,25:28) = 1;
CONSTRAINT_CROWDING(8,29:32) = 1;
CONSTRAINT_CROWDING(9,33:36) = 1;

% Split the stochiometrix matrix - 
S	=	stoichiometric_matrix(IDX_BALANCED_METABOLITES,:);
SDB	=	stoichiometric_matrix(SPECIES_BOUND(:,1),:);

% == DO NOT EDIT BELOW THIS LINE ================================== 
DF.STOICHIOMETRIC_MATRIX = stoichiometric_matrix;
DF.FLUX_BOUNDS = flux_bounds_array;
DF.SPECIES_BOUND_ARRAY = SPECIES_BOUND;
DF.SPECIES_BOUNDS_INDEX = IDX_FREE_METABOLITES;
DF.BALANCED_MATRIX = S;
DF.SPECIES_CONSTRAINTS = SDB;
DF.NUMBER_OF_REACTIONS = number_of_reactions;
DF.NUMBER_OF_STATES = number_of_species;
DF.CROWDING_COEFF_VECTOR = CROWDING_COEFF_VECTOR;
DF.CONSTRAINT_CROWDING = CONSTRAINT_CROWDING;
% ================================================================= 
return;
